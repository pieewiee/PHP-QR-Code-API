<?php

$DBserver = 'inhas68849';
$DatabaseName = 'RemoteControlGatewayDb';

?>