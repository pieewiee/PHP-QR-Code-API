﻿param (
[String]$search,
[String]$type
)

Import-Module ActiveDirectory
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

$DomainControllers = "inhdc01", 'rdgdc01', 'sihdc01'
$usersData = ""
$UsersDataObject = @()


    foreach ($DomainController in $DomainControllers) {
        if($type -eq "Azure")
        {
            $usersData = Get-ADUser -Server $DomainController -Filter "mail -eq '$search'"
        }
        if($type -eq "Ad")
        {
            $usersData = Get-ADUser -Server $DomainController -Filter "SamAccountName -eq '$search'"
        }
        
        if(![string]::IsNullOrEmpty($usersData))
        {
            break
        }
    }

    //$usersData = $DomainController | %{Get-ADUser -Server $_ -Filter "mail -eq '$search'"} 

    foreach ($user in $usersData)
    {
        $UserInfo = New-Object -TypeName psobject
        #$UserInfo | Add-Member -MemberType NoteProperty -Name GivenName -Value $user.GivenName
        #$UserInfo | Add-Member -MemberType NoteProperty -Name Surname -Value $user.Surname
        $UserInfo | Add-Member -MemberType NoteProperty -Name Name -Value $user.Name
        $UserInfo | Add-Member -MemberType NoteProperty -Name SamAccountName -Value $user.SamAccountName
        $UserInfo | Add-Member -MemberType NoteProperty -Name UserPrincipalName -Value $user.UserPrincipalName
        #$UserInfo | Add-Member -MemberType NoteProperty -Name mail -Value $user.mail
        
        
        $RawForest = $user.DistinguishedName -split ","
        $Forest = ""
        foreach ($item in $RawForest) {
            if ($item -eq "DC=eu" -or $item -eq "DC=am" -or $item -eq "DC=ap" )
            {
                $Forest = $item.replace('DC=','')
            }
        }
        $UserInfo | Add-Member -MemberType NoteProperty -Name Forest -Value $Forest
        $UsersDataObject += $UserInfo
    }
    
    $json = $UsersDataObject | ConvertTo-Json
    write-host $json
   
