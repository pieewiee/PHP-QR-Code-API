<?php


        $response = new StdClass();
        $ArrayItems = array();

        
function scan_dir($dir) {
    $ignored = array('.', '..', '.svn', '.htaccess');

    $files = array();    
    foreach (scandir($dir) as $file) {
        if (in_array($file, $ignored)) continue;
        $files[$file] = filemtime($dir . '/' . $file);
    }

    arsort($files);
    $files = array_keys($files);

    return ($files) ? $files : false;
}

        $dir = 'NetworkAllocation';
        if (file_exists($dir) && is_dir($dir) ) {

          
            $scan_arr = scan_dir($dir);
            $files_arr = array_diff($scan_arr, array('.','..') );
            foreach ($files_arr as $file) {

                $FileObject = new StdClass();
                $file_path = "NetworkAllocation/".$file;
                $file_ext = pathinfo($file_path, PATHINFO_EXTENSION);
                $fmtime = filemtime($file_path);




                if ($file_ext=="xml" ) {

                    $FileObject->date = date ("Y.m.d H:i:s.", $fmtime);
                    $FileObject->file = $file;
                    

                    if (file_exists($file_path)) {
                        $xml = simplexml_load_file($file_path);
                        
                        foreach ($xml->{'Request'} as $subkey => $subvalue) {
                            
                            foreach ($subvalue as $key => $value) {
                                $FileObject->{$key} = $value->asXml();
                            }
                        }
                        $FileObject->delete = '<button type="button" onclick="DeleteNetworAllocation(\'' . $file . '\')" class="btn btn-danger"> Delete</button>';
                        array_push($ArrayItems, $FileObject);
                    }
                }
            }
        }
        else {
          echo "Dorectory does not exists";
        }

        //sort($ArrayItems['date']);

        
        $response->total = count($ArrayItems);
        $response->totalNotFiltered = count($ArrayItems);
        $response->rows = $ArrayItems;

        print_r(json_encode($response));

?>