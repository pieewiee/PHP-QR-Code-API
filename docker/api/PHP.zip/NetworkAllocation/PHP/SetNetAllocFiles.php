<?php

    require 'AzureAD.php';
        $ArrayItems = array();

        $Request = "";
        try {
            $Request = json_decode(file_get_contents('php://input'), true);
        } catch (\Throwable $th) {
            $response = new StdClass();
            $response->success = false;
            $response->Message = "No valid Json in Post";
            print_r(json_encode($response));
            exit;
        }



        if (isset($_GET['action']))
        {

            $action = $_GET['action'];

            if ($action == "add")
            {

                $SNET = explode(",", $Request['SNETval']);
                $SNET = $SNET[0];
                $SNETOwner = explode(",", $Request['SNETval']);
                $SNETOwner = $SNETOwner[1];
        
                $RequestUSer = GetCurrentUser();
                $SNETUser = SerachUser($SNETOwner);
                

                $dir = 'NetworkAllocation';
                if (file_exists($dir) && is_dir($dir) ) {
                
                    $scan_arr = scandir($dir);
                    $files_arr = array_diff($scan_arr, array('.','..') );
                    foreach ($files_arr as $file) {
                        foreach ($Request['Computers'] as $key => $value) {
                            if($value . ".xml" == $file )
                            {
                                $response = new StdClass();
                                $response->success = false;
                                $response->Message = "Request already in place for: " . $value;
                                print_r(json_encode($response));
                                exit;
                            }
                        }
                    }

                    foreach ($Request['Computers'] as $key => $value) {
                        $xml = new SimpleXMLElement('<MyShopForm/>');

                        $Request = $xml->addChild('Request');
                        $Request->addChild('RequestType', "Move");
                        $Request->addChild('OrderNumber', "");
                        $Request->addChild('HostName', $value);
                        $Request->addChild('SNETName', $SNET);
                        $Request->addChild('SNETOwnerMail', $SNETUser->UserPrincipalName);
                        $Request->addChild('OrdererBICN', $RequestUSer->SamAccountName);
                        $Request->addChild('OrdererMail', $RequestUSer->UserPrincipalName);
                        $Request->addChild('OrderDetails', "SNET-Move");

                        $xml->asXML("NetworkAllocation/" .  $value . ".xml");

                    }
                    $response = new StdClass();
                    $response->success = true;
                    $response->Message = "Request created";
                    print_r(json_encode($response));
                }
            }

            if ($action == "delete")
            {   
                foreach ($Request as $key => $value) {
                    unlink('NetworkAllocation/' .  $value);
                    $response = new StdClass();
                    $response->success = true;
                    $response->Message = "Request deleted";
                    print_r(json_encode($response));
                }
            }
        }
        

?>