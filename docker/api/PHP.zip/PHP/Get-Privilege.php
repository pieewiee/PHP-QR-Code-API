<?php

require 'CheckUser.php';
header('Content-Type: application/json');
$files = scandir("../admin");
$results = new stdClass();


//$user = strtolower($_SERVER['AUTH_USER']);
$user = strtolower(GetCurrentUser(GetGraphToken()));

if(strpos($user, '@') !== false)
{
    //$user = strtolower(GetCurrentUser());
}

chdir('../');
$Directories = array_filter(glob('*'), 'is_dir');


$response = new StdClass();
$ArrayItems = array();

$DirectoriesExlude = array("PHP","css","js","fontawsome","bootstrap-icons", "PowerShell");

$Memberof = GetUserMemberOf(GetUserPrincipalName());



foreach ($Directories as $Dirkey => $Dirvalue) {

    if(in_array($Dirvalue, $DirectoriesExlude)) {

        continue;
    }
    $PrivfilePath =  $Dirvalue . "/web.config";
    $accessValues = new StdClass();
    $accessValues->Folder = $Dirvalue;
    
    $isMember = false;
    $Membertype = "";
    if (file_exists($PrivfilePath)) {
        $xml = simplexml_load_file($PrivfilePath);
        $Rules = $xml->{'system.webServer'}->security->authorization->add;
        
        foreach ($Rules as $key => $value) {
            if($value['accessType'] == "Allow")
            {
                if ($value['users'] == $user)
                {
                    $isMember = true;
                    $Membertype = "User";
                }
                foreach ($Memberof->value as $MemberOfKey => $MemberOfValue) {
                    if ($value['roles'] == $MemberOfValue->displayName)
                    {   
                        $isMember = true;
                        $Membertype = "Group";
                    }
                }

            }
        }

        $Roles = false;
        foreach ($Rules as $key => $value) {

            if($value['accessType'] == "Allow")
            {
                if ($value['roles'])
                {   
                    $Roles = true;
                }

                if ($value['users'] == "*")
                {
                    if( $Roles == false)
                    {
                        $isMember = true;
                        $Membertype = "All Users";
                    }
                }
            }
        }
    } else {
        $isMember = false;
    }
    
    $accessValues->isMember = $isMember;
    $accessValues->Type = $Membertype;
    array_push($ArrayItems, $accessValues);
    
}

    echo json_encode($ArrayItems, JSON_PRETTY_PRINT);


?>